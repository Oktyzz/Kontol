/* TUTOR AGAR TIDAK KE BLOKIR 

- JANGAN MENGGUNAKAN WA GB
- WAJIB PUSHKONTAK MEMAKAI .pushkontakidjd
- NO NEW JANGAN LANGSUNG DIJADIIN BOT
- PUSHKONTAK WAJIB SET JEDA 6000+ /6 DETIK+
- JANGAN PUSHKONTAK LANGSUNG 2 GC SEKALIGUS

TUTOR INI GAK WORK 100%, TAPI HANYA MENGURANGI SPAM
© ᴢᴇʀᴏᴏɴᴇᴇ ᴏғғᴄ

*/

const fs = require('fs')
const chalk = require('chalk')

global.gr = 'https://wa.me/6283138844900?text=bang+ini+link+donasi+yah+https://bit.ly/3RzpzJK+aku+mau+donasi'
global.ig = '@zeroonee89' // ubah aja
global.email = 'zeroonee24@gmail.com' //serah
global.region = 'indonesia' // serah

global.noCreator = "6283138844900"
global.namaCreator = "YT: ZEROONEOFFC"
global.namastore = "ZERO Store"
global.namaOwner = "YT: ZEROONEOFFC"
global.namabot = "ZERO BOTz"
global.namastore = 'YT ZEROONEE OFFC'
global.namaStore = 'YT ZEROONEE OFFC'
global.ownername = 'ZEROONEE OFFC' //ubah jadi nama mu, note tanda ' gausah di hapus!

global.owner = ['6283138844900'] // ubah aja pake nomor lu

global.keyopenai = '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'

global.dana = "628xx" //pake nope kalian bolee
global.ovo = "628xx" //pake nope kalian bolee
global.gopay = "628xx" //pake nope kalian bolee
global.shopeepay = "628xx" //pake nope kalian bolee
global.linkig = "@zeroonee89" // link ig lu
global.linkyt = "https://youtube.com/@Zeroonee-48_Official" // link yt lu
global.linkgc = "https://chat.whatsapp.com/ENOMHKWZ3eB2eKHT3wbyAS" // link gc lu
global.linktt = "@zeroonee89" // link tiktok lu



global.botname = 'ZEROONEE OFFC' //ubah jadi nama bot mu, note tanda ' gausah di hapus!
global.packname = 'ZEROONEE OFFC' // ubah aja ini nama sticker
global.author = 'ZEROONEE OFFC' // ubah aja ini nama sticker
global.prefa = ['','!','.',',','🐤','🗿']
global.sessionName = 'haikal' //Gausah Juga
global.sp = '⭔' // Gausah Juga
global.wlcm = []
global.wlcmm = []
global.anticall = false //ganti ke true buat on



//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})